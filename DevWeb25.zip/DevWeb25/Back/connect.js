const mysql = require('mysql2');
const readline = require('readline');

// Create a connection to the database
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'Listas'
});

// Set up the terminal interface for user input
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Connect to the MySQL database
connection.connect((err) => {
    if (err) {
        console.error('Error connecting: ' + err.stack);
        return;
    }
    console.log('Connected as id ' + connection.threadId);
    
    // Now that the connection is established, show the menu
    showMenu();
});

function CriarLista() {
    rl.question('Nome da lista: ', (nome_lista) => {
        const query = 'INSERT INTO Lista (nome_lista) VALUES (?)';
        connection.query(query, [nome_lista], (err, results) => {
            if (err) {
                console.log('Erro na inserção: ', err);
            } else {
                console.log('Lista criada.');
            }
            showMenu();
        });
    });
}

function ApagarLista() {
    rl.question('ID da lista: ', (id_lista) => {
        const query = 'DELETE FROM Lista WHERE Id_Lista = ?';
        connection.query(query, [id_lista], (err, results) => {
            if (err) {
                console.log('Erro na deleção: ', err);
            } else {
                console.log('Lista apagada.');
            }
            showMenu();
        });
    });
}

function showMenu() {
    console.log('\nO que gostaria de fazer?');
    console.log('1. Criar Lista');
    console.log('2. Apagar Lista');
    console.log('3. Acessar Lista');
    console.log('4. Sair');

    rl.question('Enter your choice: ', (choice) => {
        switch (choice) {
            case '1':
                CriarLista();
                break;
            case '2':
                ApagarLista();
                break;
            case '3':
                AcessarLista();
                break;
            case '4':
                console.log('Saindo...');
                connection.end();
                rl.close();
                break;
            default:
                console.log('Escolha inválida!');
                showMenu();
                break;
        }
    });
}

function AcessarLista() {
    const query = 'SELECT * FROM Lista';
    connection.query(query, (err, results) => {
        if (err) {
            console.log('Erro ao acessar listas: ', err);
        } else {
            console.log('Listas: ', results);
        }
        showMenu();
    });
}
