const mysql = require('mysql2');
const readline = require('readline');

// Create a connection to the database
const connection = mysql.createConnection({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'Listas'
});

// Set up the terminal interface for user input
const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});

// Connect to the MySQL database
connection.connect((err) => {
    if (err) {
        console.error('Error connecting: ' + err.stack);
        return;
    }
    console.log('Connected as id ' + connection.threadId);
    
    // Now that the connection is established, show the menu
    showMenu();
});

function CriarLista() {
    rl.question('Nome da lista: ', (nome_lista) => {
        const query = 'INSERT INTO Lista (nome_lista) VALUES (?)';
        connection.query(query, [nome_lista], (err, results) => {
            if (err) {
                console.log('Erro na inserção: ', err);
            } else {
                console.log('Lista criada.');
            }
            showMenu();
        });
    });
}

function ApagarLista() {
    rl.question('ID da lista: ', (id_lista) => {
        const query = 'DELETE FROM Lista WHERE Id_Lista = ?';
        connection.query(query, [id_lista], (err, results) => {
            if (err) {
                console.log('Erro na deleção: ', err);
            } else {
                console.log('Lista apagada.');
            }
            showMenu();
        });
    });
}

function showMenu() {
    console.log('\nO que gostaria de fazer?');
    console.log('1. Criar Lista');
    console.log('2. Apagar Lista');
    console.log('3. Acessar Lista');
    console.log('4. Sair');

    rl.question('Escolha: ', (choice) => {
        switch (choice) {
            case '1':
                CriarLista();
                break;
            case '2':
                ApagarLista();
                break;
            case '3':
                VerListas();
                break;
            case '4':
                console.log('Saindo...');
                connection.end();
                rl.close();
                break;
            default:
                console.log('Escolha inválida!');
                showMenu();
                break;
        }
    });
}

function VerListas() {
    const query = 'SELECT Id_Lista, Nome_Lista FROM Lista';
    connection.query(query, (err, results) => {
        if (err) {
            console.log('Erro ao acessar listas: ', err);
        } else {
            console.log('\nListas: ');
            results.forEach((row, index) => {
                console.log(`${index + 1}. [ID: ${row.Id_Lista}] [Nome: ${row.Nome_Lista}]`);
            });
            console.log('0. - Sair')
            AcessarLista()
        }
    });
}

function AcessarLista() {
    rl.question('Escolha ID ou sair: ', (x) => {
        if(x == 0) showMenu();
        else{
            const query = `
            SELECT 
                Lista.Id_Lista,
                Lista.Nome_Lista,
                Linha.Num AS Linha,
                Coluna.Nome_Coluna,
                Info.Dados
            FROM Lista
            INNER JOIN Linha ON Lista.Id_Lista = Linha.Lista
            INNER JOIN Info ON Linha.Id_Linha = Info.Lin
            INNER JOIN Coluna ON Info.Col = Coluna.Id_Coluna
            WHERE Lista.Id_Lista = ?
            ORDER BY Linha.Num, Coluna.Nome_Coluna
            `;
            
            connection.query(query, [x], (err, results) => {
                if (err) {
                    console.log('Erro ao acessar dados da lista: ', err);
                    showMenu();
                    return;
                }

                if (results.length === 0) {
                    console.log('Nenhum dado encontrado para essa lista.');
                    showMenu();
                    return;
                }

                console.log(`\nLista: ${results[0].Nome_Lista} (ID: ${results[0].Id_Lista})`);
                
                let currentLine = null;
                results.forEach(row => {
                    if (row.Linha !== currentLine) {
                        currentLine = row.Linha;
                        console.log(`\nLinha ${currentLine}:`);
                    }
                    console.log(`  ${row.Nome_Coluna}: ${row.Dados}`);
                });

                showMenu();
            });
        }
    });
}